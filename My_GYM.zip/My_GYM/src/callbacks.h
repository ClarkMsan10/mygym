#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_but_view_profil_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_but_deconnect_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_but_return_menu_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_valid_mod_prof_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_but_mod_prof_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_annuler_mod_prof_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_but_view_list_adhr_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



/*void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
					GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_but_affecter_reg_clicked            (GtkWidget  *objet_graphique,
                                        gpointer         user_data);*/


/*void
on_button2_clicked                     (GtkWidget	*objet_graphique,
                                        gpointer         user_data);*/

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

/*void
on_button3_clicked                     (GtkWidget	*objet_graphique,
                                        gpointer         user_data);*/

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_but_return_menu_affich_list_adhr_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);


void
on_but_affect_reg_select_clicked       (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_but_affect_reg_clicked              (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_but_gest_reg_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_but_select_reg_clicked              (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_but_return_affect_list_adhr_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void on_but_affect_reg_pers_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

/*void
on_button2_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);*/

void
on_but_valid_affect_reg_pers_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_but_cancel_affect_reg_pers_affect_reg_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
