#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonction.h"


enum {

	NOM,
	POIDS, 
	REGIME,
	COLUMNS
};

int verif ( char a[20] , char b[20] ){


	char log[20], pswd[20] ; 
	FILE* fichier ;

	fichier = fopen ( "user.txt" , "r" );
	
	rewind(fichier) ;

	while(fscanf( fichier, "%s %s", log, pswd ) != EOF ){

	if( strcmp ( a, log ) == 0 && strcmp ( b, pswd ) == 0 )	{
	
				fclose(fichier);return(1) ;
						}

	}

	fclose(fichier);
	return 0 ;

}


/*void ajouter ( char r[] ){

FILE* fichier ; 

fichier = fopen("regime.txt" , "a+" );

	if(fichier != NULL )
			fprintf(fichier, "%s \n", r );
			

	fclose(fichier);
}*/


void lecture_label( char jour[50] , char heure[30] , char prix[5] ){

	FILE *fichier = fopen("dispo.txt" , "a+" );
        
	rewind(fichier ) ;

	fscanf(fichier , "%s %s %s" , jour, heure, prix);

	fclose(fichier) ; 
} 
 


int Remp( prend prend[10] ){

	int ns = 0 ;
	FILE *fichier = fopen("reg_typ.txt", "r");

	char mots[10] ;

	while(fscanf(fichier, "%s", mots)!=EOF){
	
	strcpy( prend[ns].mot , mots);
	ns++ ;
				}
	fclose(fichier);
	return ns ;
}

void affect_reg(char type_regime[]){

	
	char nom[20] , poids[10] , typ_regime[10] ;
	char name[20] , weight[10] , diet[10];
	FILE *temp_info = fopen("temp.txt" , "r");
	FILE *fichier = fopen("Adherents.txt" , "a+" );
	FILE *nouveau = fopen("nouveau_tmp.txt", "w+");
	while(fscanf(temp_info , "%s %s %s", nom, poids, typ_regime) !=EOF ){
 	fclose(temp_info);
	temp_info = fopen("temp.txt" , "w+" );
	fprintf(temp_info , "%s %s %s", nom, poids, type_regime);}
	fclose( temp_info);
	

	while(fscanf( fichier, "%s %s %s", name, weight, diet ) != EOF) {
	
	printf("Il est dedans");
	if(strcmp(name,nom)== 0 && strcmp(weight,poids) == 0){

		fprintf(nouveau, "%s %s %s \n", name, weight, type_regime);
		printf("Trouvé \n");
		
	}
	else{
		fprintf(nouveau, "%s %s %s \n", name, weight, diet) ;
		printf("Different \n");
	}
}

	fclose(fichier) ;
	fclose(nouveau);



	rename("nouveau_tmp.txt" , "Adherents.txt");

}

void ajout_reg_pers( char a[] , char b[], char c[], char d[], FILE *fichier ){

FILE *reg = fopen("regime.txt", "a+");
	FILE *typ_reg = fopen("reg_typ.txt", "a+");

	while( fscanf(fichier, "%s %s %s %s" , a, b, c, d ) != EOF ){ fprintf(reg, "%s %s %s %s\n" , a, b, c, d ) ; 
		fprintf(typ_reg, "%s\n" , a );}

fclose(reg);
	fclose(typ_reg);

	affect_reg(a);
	


}

