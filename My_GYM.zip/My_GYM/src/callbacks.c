#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "acu.h"

typedef struct oui {
	char non[10] ;} oui ;

int Rempi( oui yes[10] ){

	int ns = 0 ;
	FILE *fichier = fopen("reg_typ.txt", "r");

	char mot[10] ;
	if(fichier == NULL){ printf("Erreur ouverture fichier \n");}
	while(fscanf(fichier, "%s", mot)!=EOF){
	printf("COpie");
	strcpy( yes[ns].non , mot);
	ns++ ;
				}
	fclose(fichier);
	return ns ;
}

//Authentification vers menu
void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	GtkWidget *input1, *input2, *output, *window1, *window2  ;
	char login[20] , password[20];


	window2 = lookup_widget(objet_graphique, "win_menu" );
	window1 = lookup_widget(objet_graphique, "win_authentification" );	
	input1 = lookup_widget(objet_graphique, "entry1" );
	input2 = lookup_widget(objet_graphique, "entry2" );
	output = lookup_widget(objet_graphique, "label3" );


	strcpy( login , gtk_entry_get_text(GTK_ENTRY(input1) ) ); 
	strcpy( password , gtk_entry_get_text( GTK_ENTRY(input2) ) );


	 

	if( verif( login, password ) == 1){
		
			window2 = create_win_menu();
  			gtk_widget_show (window2);
			gtk_widget_hide(window1);
			}
				
	
	else{
		gtk_label_set_text(GTK_LABEL(output), "Non validé" );
		
		gtk_entry_set_text(GTK_ENTRY(input1), " ");

		gtk_entry_set_text(GTK_ENTRY(input2), " " );

		
		}

}






//Menu vers Profil

void
on_but_view_profil_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2  ;

	window2 = create_win_profil();
	window1 = lookup_widget(objet_graphique, "win_menu" );
	window2 = lookup_widget(objet_graphique, "win_profil" );
	
  	gtk_widget_show (window2);
	gtk_widget_hide(window1);	
	
}


void
on_but_deconnect_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}




//profil vers menu
void
on_but_return_menu_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2  ;

	window2 = create_win_menu();
	window1 = lookup_widget(objet_graphique, "win_profil" );
	window2 = lookup_widget(objet_graphique, "win_menu" );
	
  	gtk_widget_show (window2);
	gtk_widget_hide(window1);
}








/*void
on_Annuler_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2  ;


	window1 = lookup_widget(objet_graphique, "win_profil_mod" );
	window2 = lookup_widget(objet_graphique, "win_profil" );
	window2 = create_win_profil();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}*/



//modifier profil vers profil apres validation
void
on_button_valid_mod_prof_clicked       (GtkWidget  *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *combo_jour , *combo_heure, *honoraire ;
	char jour[50] , heure[50] ;
	FILE *fichier = fopen("dispo.txt", "w+");
	int prix ;

	combo_jour = lookup_widget( objet_graphique, "combobox_jour" );
	combo_heure = lookup_widget( objet_graphique, "combobox_heure" );
	honoraire = lookup_widget( objet_graphique, "spinbutton_honoraire" );
	
if(fichier != NULL) {
	strcpy( jour , gtk_combo_box_get_active_text (GTK_COMBO_BOX(combo_jour)));
	strcpy( heure , gtk_combo_box_get_active_text (GTK_COMBO_BOX(combo_heure)));
	prix = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(honoraire) ) ;}

	fprintf(fichier, "%s %s %d ", jour, heure, prix );

	fclose(fichier);
	
	GtkWidget *window1, *window2  ;
	window2 = create_win_profil();
	window1 = lookup_widget(objet_graphique, "win_mod_prof" );
	window2 = lookup_widget(objet_graphique, "win_profil" );
	
  	gtk_widget_show (window2);
	gtk_widget_hide(window1);
	
	
}

//profil vers modifier profil
void
on_but_mod_prof_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
		GtkWidget *window1, *window2  ;
		window2 = create_win_mod_prof();

	window1 = lookup_widget(objet_graphique, "win_profil" );
	window2 = lookup_widget(objet_graphique, "win_mod_prof" );
	
  	gtk_widget_show (window2);
	gtk_widget_hide(window1);	
}

//modifier profil vers profil
void
on_button_annuler_mod_prof_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window2  ;
	window2 = create_win_profil();
	window1 = lookup_widget(objet_graphique, "win_mod_prof" );
	window2 = lookup_widget(objet_graphique, "win_profil" );
	
  	gtk_widget_show (window2);
	gtk_widget_hide(window1);
}


//menu vers liste adherant et regime
void
on_but_view_list_adhr_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2  ;
GtkWidget *combobox2 ;
	
	
	window1 = lookup_widget(objet_graphique, "win_menu" );
	window2 = lookup_widget(objet_graphique, "win_list_adhr" );
        window2 = create_win_list_adhr();
  	gtk_widget_show (window2);
	gtk_widget_hide(window1);
	GtkWidget *treeview1, *treeview2 ;
	treeview1 = lookup_widget(window2, "treeview1");
	treeview2 = lookup_widget(window2, "treeview2");
	afficher_list_adhr( treeview1 );
	afficher_list_regime( treeview2);

	
}



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
		

	gchar *nom, *poids, *type_regime ;
	FILE *temp = fopen("temp.txt", "w+");	
	GtkTreeIter iter  ;
	GtkTreeModel *model ;
	
	model = gtk_tree_view_get_model(treeview);
	gtk_tree_model_get_iter ( model, &iter, path);
	gtk_tree_model_get ( model, &iter, NOM, &nom, POIDS, &poids, REGIME, &type_regime, -1 );
	fprintf (temp,"%s %s %s\n", nom, poids, type_regime );
	printf("activated : %s %s %s\n", nom, poids, type_regime );
	fclose(temp);


	g_free(nom);
	g_free(poids);
	g_free(type_regime);
}

/*
void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}*/


/*void
on_but_affecter_reg_clicked            (GtkWidget  *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *combobox2 ;
	int n , i ;
	oui yes[10] ;
		
	combobox2 = lookup_widget( objet_graphique, "combobox2" );

	
	n = Rempi(yes); 
	for( i = 0 ; i < n ; i++ ){
	gtk_combo_box_append_text(GTK_COMBO_BOX(combobox2), _(yes[i].non ) );

	}
}*/


/*void
on_button2_clicked                     (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *combobox2 ;
	int n , i ;
	oui yes[10] ;
		
	combobox2 = lookup_widget( objet_graphique, "combobox1" );

	
	n = Rempi(yes); 
	for( i = 0 ; i < n ; i++ ){
	gtk_combo_box_append_text(GTK_COMBO_BOX(combobox2), _(yes[i].non ) );

	}
}*/




/*void
on_button3_clicked                     (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *combobox2 ;
	char msan[20] ;
	FILE *tempo = fopen("affect_reg_tmp.txt" , "w+" ); 

	combobox2 = lookup_widget( objet_graphique, "combobox1" );
	
	strcpy( msan , gtk_combo_box_get_active_text (GTK_COMBO_BOX(combobox2)));

	fprintf(tempo, "%s \n" , msan );

	fclose(tempo);
}*/


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}




void
on_but_return_menu_affich_list_adhr_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


/*void affect_reg(char type_regime[]){

	
	char nom[20] , poids[10] , typ_regime[10] ;
	char name[20] , weight[10] , diet[10];
	FILE *temp_info = fopen("temp.txt" , "r");
	FILE *fichier = fopen("Adherents.txt" , "a+" );
	FILE *nouveau = fopen("nouveau_tmp.txt", "w+");
	while(fscanf(temp_info , "%s %s %s", nom, poids, typ_regime) !=EOF ){
 	fclose(temp_info);
	temp_info = fopen("temp.txt" , "w+" );
	fprintf(temp_info , "%s %s %s", nom, poids, type_regime);}
	fclose( temp_info);
	

	while(fscanf( fichier, "%s %s %s", name, weight, diet ) != EOF) {
	
	if(strcmp(name,nom)== 0 && strcmp(weight,poids) == 0){

		fprintf(nouveau, "%s %s %s \n", name, weight, type_regime);
		
		
	}
	else{
		fprintf(nouveau, "%s %s %s \n", name, weight, diet) ;
		
	}
}

	fclose(fichier) ;
	fclose(nouveau);



	rename("nouveau_tmp.txt" , "Adherents.txt");

}*/


void
on_but_affect_reg_select_clicked       (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
	
GtkWidget *combobox1 , *label;
char type_regime[12];

combobox1 = lookup_widget( objet_graphique, "combobox1" );

label = lookup_widget( objet_graphique, "lab_conf_affect");


strcpy( type_regime , gtk_combo_box_get_active_text (GTK_COMBO_BOX(combobox1)));

affect_reg( type_regime );

gtk_label_set_text(GTK_LABEL(label), "Regime Affecté" );

}


void
on_but_affect_reg_clicked              (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
  

	GtkWidget *window1, *window2  ;	
	
	
	window1 = lookup_widget(objet_graphique, "win_list_adhr" );
	window2 = lookup_widget(objet_graphique, "win_affect_reg" );
	window2 = create_win_affect_reg();
	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
	GtkWidget *treeview3 ;
	treeview3 = lookup_widget(window2, "treeview3");
	afficher_list_regime( treeview3);

	
}


void
on_but_gest_reg_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	
}


void
on_but_select_reg_clicked              (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *combobox1 ;
	int n , i ;
	oui yes[20] ;
		
	combobox1 = lookup_widget( objet_graphique, "combobox1" );

	
	n = Rempi(yes); 
	for( i = 0 ; i < n ; i++ ){
	gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1), _(yes[i].non ) ); }
}


void
on_but_return_affect_list_adhr_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2  ;
	
	
	window1 = lookup_widget(objet_graphique, "win_affect_reg" );
	window2 = lookup_widget(objet_graphique, "win_list_adhr" );
        window2 = create_win_list_adhr();
  	gtk_widget_show (window2);
	gtk_widget_hide(window1);
	GtkWidget *treeview1, *treeview2 ;
	treeview1 = lookup_widget(window2, "treeview1");
	treeview2 = lookup_widget(window2, "treeview2");
	afficher_list_adhr( treeview1 );
	afficher_list_regime( treeview2);

	
}

void on_but_affect_reg_pers_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data){ 

	GtkWidget *window1 , *window2 ;

	window1 = lookup_widget( objet_graphique , "win_affect_reg");
	window2 = lookup_widget( objet_graphique , "win_affect_reg_pers");

	window2 = create_win_affect_reg_pers();
	gtk_widget_show(window2);
	gtk_widget_destroy(window1);

}




/*void
on_button2_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	printf("C'est bon");	

	GtkWidget *input1, *input2, *input3 ;
	
	char ent1[30] , ent2[40] , ent3[50] ; 

	FILE *fichier =  fopen("azer.txt" , "w+");
	printf("C'est bon");
	
	input1 = lookup_widget( objet_graphique , "entry3");
	input2 = lookup_widget( objet_graphique , "entry4");
	input3 = lookup_widget( objet_graphique , "entry5");

	strcpy( ent1 , gtk_entry_get_text( GTK_ENTRY(input1) ) );
	strcpy( ent2 , gtk_entry_get_text( GTK_ENTRY(input2) ) );
	strcpy( ent3 , gtk_entry_get_text( GTK_ENTRY(input3) ) );

	fprintf(fichier, "%s %s %s", ent1, ent2, ent3 );

	fclose(fichier);
}*/


/*void ajout_reg_pers( char a[] , char b[], char c[], char d[], FILE *fichier ){

FILE *reg = fopen("regime.txt", "a+");
	FILE *typ_reg = fopen("reg_typ.txt", "a+");

	while( fscanf(fichier, "%s %s %s %s" , a, b, c, d ) != EOF ){ fprintf(reg, "%s %s %s %s\n" , a, b, c, d ) ; 
		fprintf(typ_reg, "%s\n" , a );}

fclose(reg);
	fclose(typ_reg);

	affect_reg(a);
	


}*/

void
on_but_valid_affect_reg_pers_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *input1, *input2, *input3 , *input4;
	
	char type_regime[30] , petit_dej[40] , soupet[50], diner[45] ; 

	FILE *fichier =  fopen("nv_reg_pers.txt" , "w+");
	printf("C'est bon");
	
	input1 = lookup_widget( objet_graphique , "entry_type_regime");
	input2 = lookup_widget( objet_graphique , "entry_petit_dejeuner");
	input3 = lookup_widget( objet_graphique , "entry_soupet");
	input4 = lookup_widget( objet_graphique , "entry_diner");

	strcpy( type_regime , gtk_entry_get_text( GTK_ENTRY(input1) ) );
	strcpy( petit_dej , gtk_entry_get_text( GTK_ENTRY(input2) ) );
	strcpy( soupet , gtk_entry_get_text( GTK_ENTRY(input3) ) );
	strcpy( diner , gtk_entry_get_text( GTK_ENTRY(input4) ) );

	fprintf(fichier, "%s %s %s %s", type_regime, petit_dej, diner, soupet  );

	rewind(fichier);
	
	ajout_reg_pers(type_regime, petit_dej, diner, soupet, fichier);

	fclose(fichier);

	remove("nv_reg_pers.txt");
	
	
}


void
on_but_cancel_affect_reg_pers_affect_reg_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	GtkWidget *window1 , *window2 ;
	
	window1 = lookup_widget( objet_graphique , "win_affect_reg_pers");
	window2 = lookup_widget( objet_graphique , "win_affect_reg");
	
	window2 = create_win_affect_reg();
	gtk_widget_show(window2);
	gtk_widget_destroy(window1);	
	GtkWidget *treeview3 ;
	treeview3 = lookup_widget(window2, "treeview3");
	afficher_list_regime( treeview3);	
}

