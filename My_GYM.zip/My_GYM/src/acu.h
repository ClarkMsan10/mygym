#include <gtk/gtk.h>

enum {

	NOM,
	POIDS, 
	REGIME,
	COLUMNS
};

enum {
	TYP_REGIME, 
	PETIT_DEJ,
	DINER,
	SOUPET,
	COLUMN

};

void afficher_list_adhr(GtkWidget *liste);
void afficher_list_regime( GtkWidget *liste );
