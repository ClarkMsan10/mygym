#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "fonction.h"
#include "acu.h"

enum{

	TYP = 40,
	DEJ = 41,
	DIN = 42,
	SPT = 43,
	COLUM	};



void afficher_list_adhr(GtkWidget *liste){


	GtkCellRenderer *renderer ; 
	GtkTreeViewColumn *column ;
	GtkTreeIter 	iter ;

        GtkListStore *store ;

	char nom[20], poids[10], type_regime[10] ;
	FILE *fichier ;

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("NOM", renderer , "text" , NOM , NULL);
	        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column );


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("POIDS", renderer , "text" , POIDS , NULL);
	        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column );


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("REGIME", renderer , "text" , REGIME , NULL);
	        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column );

		store =gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING ,G_TYPE_STRING);

	fichier= fopen("Adherents.txt", "r");

	if(fichier != NULL ){
	
		while(fscanf(fichier, "%s %s %s \n",nom, poids, type_regime) != EOF){
    gtk_list_store_append (store, &iter);
    gtk_list_store_set(store, &iter, NOM,nom, POIDS, poids, REGIME, type_regime, -1);
	} fclose(fichier);

	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store) ) ;
	g_object_unref(store) ;

}

}


void afficher_list_regime( GtkWidget *liste ){

	GtkCellRenderer *renderer ; 
	GtkTreeViewColumn *column ;
	GtkTreeIter 	iter ;

        GtkListStore *store ;

	char petit_dej[50], diner[50], soupet[50],  type_regime[10] ;
	FILE *fichier ;


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Regime", renderer , "text" , TYP_REGIME , NULL);
	        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column );
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Petit Dejeuner", renderer , "text" , PETIT_DEJ , NULL);
	        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column );


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Diner", renderer , "text" , DINER , NULL);
	        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column );

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Soupet", renderer , "text" , SOUPET , NULL);
	        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column );

		

		store =gtk_list_store_new(COLUMN,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING ,G_TYPE_STRING);

	fichier= fopen("regime.txt", "r");
	
	if(fichier != NULL ){
		rewind(fichier);
		while(fscanf(fichier, "%s %s %s %s\n",type_regime, petit_dej, diner, soupet) != EOF){
    gtk_list_store_append (store, &iter);
    gtk_list_store_set(store, &iter, TYP_REGIME,type_regime, PETIT_DEJ, petit_dej, DINER, diner,SOUPET, soupet, -1);
	} fclose(fichier);

	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store) ) ;
	g_object_unref(store) ;

}

}

