typedef struct COMBO {
	char mot[20] ;} prend ;


int verif ( char a[20] , char b[20] );

int ajouter ( char r[] );

void lecture_label( char jour[50] , char heure[30] , char prix[5] );

int Remp( prend prend[10] );


void affect_reg(char type_regime[]);

void ajout_reg_pers( char a[] , char b[], char c[], char d[], FILE *fichier );
